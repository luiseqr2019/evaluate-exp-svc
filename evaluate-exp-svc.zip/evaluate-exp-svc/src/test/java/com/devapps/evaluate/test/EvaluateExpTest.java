package com.devapps.evaluate.test;

import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.devapps.evaluate.process.EvaluateProcess;
import com.devapps.evaluate.process.IEvaluateProcess;
import com.devapps.evaluate.request.pojo.RequestPojo;

@RunWith(SpringRunner.class)
@SpringBootTest
class EvaluateExpTest {
	private IEvaluateProcess<RequestPojo,ResponseEntity<?>> evaluateProcess;
	
	@Autowired
	private Environment env;
	
//	@Before
//	public void initMocks() {
//		this.env = Mockito.mock(Environment.class);
//	}
	
	@Test
	void evaluateTest() {
		RequestPojo request = new RequestPojo();
		
		EvaluateProcess process = new EvaluateProcess(env);
		request.setExp("1+2.5/3*4");
		ResponseEntity<?> resp = process.evaluate(request);
		assertNotEquals(resp, null);
		
	}
	
	void evaluateMenosTest() {
		RequestPojo request = new RequestPojo();
		
		EvaluateProcess process = new EvaluateProcess(env);
		request.setExp("1+2.5-3*4");
		ResponseEntity<?> resp = process.evaluate(request);
		assertNotEquals(resp, null);
		
	}

}
