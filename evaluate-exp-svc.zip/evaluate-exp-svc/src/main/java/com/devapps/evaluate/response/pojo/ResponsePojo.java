package com.devapps.evaluate.response.pojo;

public class ResponsePojo {
	private String infix;
	private String posFix;
	private double value;
	
	public String getInfix() {
		return infix;
	}
	public void setInfix(String infix) {
		this.infix = infix;
	}
	public String getPosFix() {
		return posFix;
	}
	public void setPosFix(String posFix) {
		this.posFix = posFix;
	}
	public double getValue() {
		return value;
	}
	public void setValue(double value) {
		this.value = value;
	}
	
	

}
