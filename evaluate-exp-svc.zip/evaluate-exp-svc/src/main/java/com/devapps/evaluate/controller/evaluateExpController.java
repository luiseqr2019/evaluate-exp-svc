package com.devapps.evaluate.controller;

import javax.xml.ws.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.devapps.evaluate.process.IEvaluateProcess;
import com.devapps.evaluate.request.pojo.RequestPojo;

@RestController
public class evaluateExpController {
	private IEvaluateProcess<RequestPojo,ResponseEntity<?>> process;
	
	@Autowired
	public evaluateExpController(@Qualifier("EvaluateProcess")IEvaluateProcess<RequestPojo,ResponseEntity<?>> process) {
		this.process = process;
	}
	
	
	@RequestMapping(method=RequestMethod.POST,value="/evaluate")
	public ResponseEntity<?> evaluateExpression(@RequestBody RequestPojo request){
		return 	process.evaluate(request);
	}
}
