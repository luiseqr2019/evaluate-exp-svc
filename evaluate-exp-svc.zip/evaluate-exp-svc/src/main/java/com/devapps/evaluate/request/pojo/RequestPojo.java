package com.devapps.evaluate.request.pojo;

public class RequestPojo {
	private String exp;

	public String getExp() {
		return exp;
	}

	public void setExp(String exp) {
		this.exp = exp;
	}

}
