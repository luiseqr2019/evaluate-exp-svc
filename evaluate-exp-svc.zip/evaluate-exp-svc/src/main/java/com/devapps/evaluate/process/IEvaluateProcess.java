package com.devapps.evaluate.process;

public interface IEvaluateProcess<I, O> {
	public O evaluate(I request);
}
