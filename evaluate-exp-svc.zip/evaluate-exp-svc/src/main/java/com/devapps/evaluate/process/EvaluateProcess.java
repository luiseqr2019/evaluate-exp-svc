package com.devapps.evaluate.process;

import java.util.Stack;

import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.devapps.evaluate.request.pojo.RequestPojo;
import com.devapps.evaluate.response.pojo.ResponsePojo;

@Service("EvaluateProcess")
public class EvaluateProcess implements IEvaluateProcess<RequestPojo, ResponseEntity<?>>{
	private Environment env;
	
	public EvaluateProcess(Environment env) {
		this.env = env;
	}
	@Override
	public ResponseEntity<?> evaluate(RequestPojo request) {
		
		char[] operacion = request.getExp().toCharArray();
		ResponsePojo response = new ResponsePojo();
		Stack<String> output = new Stack<String>();
		Stack<String> opr = new Stack<String>();
		
		String oper = env.getProperty("appProperties.oper");
		
		for (char car : operacion) {
			if(oper.contains(String.valueOf(car))) {
				validaPrecedencia(opr,output,car);
				opr.push(String.valueOf(car));
			}else if((Character.isDigit(car) || ".".equals(String.valueOf(car))) && !output.empty()){
				output.push(output.peek() + String.valueOf(car)); 
			}else if((Character.isDigit(car) || ".".equals(String.valueOf(car))) && output.empty()) {
				output.push(String.valueOf(car));
			}else {
				return new ResponseEntity<>(response, HttpStatus.resolve(Integer.parseInt(env.getProperty("appProperties.errorResponse"))));
			}	
				
		}
		
		//agregando operadores restantes 
		for (String op : opr) {
			if(env.getProperty("appProperties.mayorPrec").contains(op))
				output.push(output.peek()+op);
		}
		for (String op : opr) {
			if(env.getProperty("appProperties.menorPrec").contains(op))
				output.push(output.peek()+op);
		}
		
		//Agregando response
		response.setInfix(request.getExp());
		response.setPosFix(output.peek());
		response.setValue(2);

		return new ResponseEntity<>(response, HttpStatus.resolve(Integer.parseInt(env.getProperty("appProperties.successResponse"))));
	}
	private void validaPrecedencia(Stack<String> opr, Stack<String> output, char car) {
		if(!opr.empty()) {
			if(env.getProperty("appProperties.mayorPrec").contains(opr.peek()) && env.getProperty("appProperties.mayorPrec").contains(String.valueOf(car))){
					output.push(output.peek() + opr.pop());
				
			}
			
			if(env.getProperty("appProperties.menorPrec").contains(opr.peek()) && env.getProperty("appProperties.menorPrec").contains(String.valueOf(car))){
				output.push(output.peek() + opr.pop());
			
			}
		}
		
	}

	
	


}
